from distutils.core import setup

setup(
    name='Cosmo_calc',
    version='',
    packages=[''],
    url='',
    license='',
    author='Caffe',
    author_email='',
    description=''
)
