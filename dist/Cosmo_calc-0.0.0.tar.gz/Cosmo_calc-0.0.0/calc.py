__author__ = 'Caffe'

import calculator


arguments = calculator.parse_arguments()
calculator.main(arguments)